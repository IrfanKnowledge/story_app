class StringHelper {
  static const emptyData = 'Data kosong (tidak ada data)';
  static const noInternetConnection = 'Tidak ada jaringan internet, coba periksa jaringan internet yang anda gunakan! :)';
  static const failedToLoadData = 'Gagal memuat data';
}