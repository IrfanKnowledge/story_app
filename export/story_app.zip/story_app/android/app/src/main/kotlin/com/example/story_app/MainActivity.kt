package com.example.story_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
